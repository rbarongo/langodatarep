#running these files: pip install -r requirements.txt
cryptography==39.0.1
python-dotenv==0.21.0
pandas==1.5.3
oracledb==2.0.0  # Adjust according to the version you're using for Oracle DB


