from setuptools import setup, find_packages

setup(
    name='utils',
    version='1.0.0',
    packages=find_packages(),
    description='A utility package for MSP2 extraction',
    author='Rweyemamu Barongo',
    author_email='ribarongo@bot.go.tz',
)




