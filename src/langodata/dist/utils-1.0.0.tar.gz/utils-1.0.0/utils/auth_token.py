"""
Explanation
DatabaseConnection Class:

The DatabaseConnection class abstracts the logic of connecting to Oracle databases. It accepts a data_source parameter (either "BSIS" or "EDI"), decrypts the credentials if necessary, and provides an interface to execute queries.
Reusability:

Both scripts (check_user_status.py and auth_token.py) import the DatabaseConnection class, making the database connection and query execution logic reusable and centralized.
Token Management:

The authenticate_user function checks if the user has a valid token. If not, it prompts for credentials, verifies the user’s existence and active status in the BSIS database, and then generates a new token.
"""

import os
import jwt  # Install this package with pip install pyjwt
from datetime import datetime, timedelta
from utils.database import DatabaseConnection
from utils.logger import Logger
from utils.license_manager import validate_license
import requests
import sys
import getpass

CERT_PATH = os.path.join(os.getcwd(), "certificate", "_.bot.go.tz.crt")

sys.path.insert(0, os.path.abspath(os.path.join(os.getcwd(), '../MSPUsersDev')))


# Define the secret key for token generation
#SECRET_KEY = "spectacular"
#SECRET_KEY = os.getenv("SECRET_KEY", "spectacular")
#LOGIN_URL = os.getenv("LOGIN_URL", "https://help.bot.go.tz:9090")
#CERT_PATH = os.getenv("CERT_PATH", "./certificate/_.bot.go.tz.crt")


SECRET_KEY = os.getenv("SECRET_KEY")
LOGIN_URL = os.getenv("LOGIN_URL")
#CERT_PATH = os.getenv("CERT_PATH")
#CERT_PATH = "_.bot.go.tz.crt"
#CERT_PATH = os.path.join(os.getcwd(), "certificate", "_.bot.go.tz.crt")

def generate_token(username):
    """Generate a JWT token with a 30-minute expiration."""
    logger = Logger()
    try:
        expiration_time = datetime.utcnow() + timedelta(minutes=30)
        token = jwt.encode({"username": username, "exp": expiration_time}, SECRET_KEY, algorithm="HS256")
        logger.info(f"Token generated that expires at {expiration_time}")
        #os.environ["USER_TOKEN"] = token
        return token
    except Exception as e:
        logger.error(f"Error generating token: {e}")
        return None


def verify_token(token):
    """Verify if the token is valid and not expired."""
    logger = Logger()
    try:
        decoded_token = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        logger.info(f"Token validated successfully")
        return decoded_token
    except jwt.ExpiredSignatureError:
        logger.debug(f"Token has expired") 
    except jwt.InvalidTokenError:
        logger.debug(f"Invalid token")
    return None  


def perform_domain_login(username, password):
    """Placeholder for domain login logic."""
    logger = Logger()
    session = requests.Session()
    payload = {"username": username, "password": password, "submit": "Login"}
    
    try:
        response = session.post(LOGIN_URL, data=payload, verify=CERT_PATH)
        if response.status_code == 200:
            logger.info("Domain validation completed successfully")
            return True
        else:
            logger.error(f"Login failed with status code: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        logger.error(f"Domain login error: {e}")
        return False    
    
       
def authenticate_user():
    logger = Logger()    
    domainLogin = False
    token = ""
    
    try:
        token = os.getenv("USER_TOKEN")

        #if token:
        decoded_token = verify_token(token)
        if decoded_token:
            logger.info(f"Existing token is valid")
            domainLogin = True
            return token
    
    except Exception as e:
        logger.error(f"{e}") 

    else:
        # Prompt for login credentials
        print("Please log in to continue.")
        username = input("Username: ")
        password = getpass.getpass("Password: ")
    
        bsis_username = username.upper()

        # Perform login and verify user status in BSIS database
        try:
            if not perform_domain_login(username, password):
                logger.error(f"Login verification failed.")
                return None
        except Exception as e:
            logger.error(f"Connectivity or other error: {e}")
                #return None

    if domainLogin == True:      
        try:
            with DatabaseConnection("BSIS") as db:
                query = """
                SELECT USERNAME, ACCOUNT_STATUS
                FROM BSIS_DEV.bsis_users
                WHERE USERNAME = :username
                """
                user_record = db.execute_query(query, {'username': bsis_username})
                #if ((user_record and user_record[0][1] == 'I' ) & (user_record and user_record[0][1] == 'A')):  # Checking status 'A' for active
                if (user_record and user_record[0][1] == 'A'):  # Checking status 'A' for active
                    logger.info("User is active and verified")
                else:
                    logger.warning("User not found or not inactive")
                return None
        except Exception as e:
            logger.error(f"Database error: {e}")
            return None        

        # Generate and return a new token
        token = generate_token(username)
        if verify_token(token):
            os.environ["USER_TOKEN"] = token
            logger.info("Authentication successful")
            return token

# Example usage
if __name__ == "__main__":
    authenticate_user()
