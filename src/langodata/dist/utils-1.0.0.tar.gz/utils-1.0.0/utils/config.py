import userConfig as ucfg
#CONFIGURATION FILE
dataLicense = ucfg.dataLicense

#File paths configurations
dataCollectionFolder=ucfg.dataCollectionFolder

#BSIS
bDsn  = "172.16.1.167:1521/BOT1DB" #"BSIS"

#EDI
eDsn  = "EDIPROD"

