import os
import pandas as pd
from utils.database import DatabaseConnection
from utils.logger import Logger
from utils.license_manager import validate_license, check_license_status
from utils.auth_token import authenticate_user

def read_data(data_group, data_source, data_type, bank_code, start_period, end_period):
    logger = Logger()
    feedback = {"info": "", "debug": "", "df": pd.DataFrame()}
    valid_license = False
    valid_user = False
    valid_input = True

    
    # Validate license
    print("\nstart validating MSP User Data Tool version")
    try:
        validate_license()
        valid_license = check_license_status()
    except Exception as e:
        feedback["debug"] += logger.error(f"License validation failed: {str(e)}")
        return feedback
    else:
        print("software validated completed")           

    
    # Validate inputs
    print("\nstart validating user inputs")    
    if ((valid_license == True) & (valid_user == True)):  
        if data_group not in ["MSP", "ITRS", "NPS", "BANK", "FUNDS", "MORGAGE", "LEASING", "TMS", "FXCFMIS", "CBR"]:
            feedback["info"] += logger.debug(f"Invalid data source: {data_source}")
            valid_input = False           
        if data_source not in ["BSIS", "EDI"]:
            feedback["info"] += logger.debug(f"Invalid data source: {data_source}")
            valid_input = False
        if data_type not in [f"{i:02}" for i in range(1, 11)] + ["*"]:
            feedback["info"] += logger.debug(f"Invalid data type: {data_type}")
            valid_input = False
        
        # Validate date format (assume 'DD-MMM-YYYY')
        try:
            datetime.strptime(start_period, "%d-%b-%Y")  # e.g., 30-SEP-2024
        except ValueError:
            feedback["info"] += logger.debug(f"Invalid start_period: {start_period}. Expected format: DD-MMM-YYYY")
            valid_input = False
        try:
            datetime.strptime(end_period, "%d-%b-%Y")  # e.g., 30-DEC-2024
        except ValueError:
            feedback["info"] += logger.debug(f"Invalid end_period: {end_period}. Expected format: DD-MMM-YYYY")
            valid_input = False

    if not valid_input:
        return feedback
    print("inputs validation completed") 
    
    
    #authenticate user 
    print("\nstart authenticating user")    
    if (valid_license == True):    
        valid_user = authenticate_user()        
        print("\nuser authentication completed")
    
    # Database connection
    print("\ndata retrieving") 
    try:
        with DatabaseConnection(data_source) as conn:
            schema = "BSIS_DEV" if data_source == "BSIS" else "EDI"
            sql = f"""
                SELECT * FROM {schema}.MSP2_{data_type}
                WHERE {'1=1' if bank_code == '*' else f"INSTITUTIONCODE = '{bank_code}'"}
                AND TRUNC(REPORTINGDATE) BETWEEN '{start_period}' AND '{end_period}'
            """
            data = conn.execute_query(sql)
            print("connected to data source")
            columns = ["INSTITUTIONCODE", "REPORTINGDATE", "DESCRIPTIONNO", "PARTICULARS", "AMOUNT"]
            feedback["df"] = pd.DataFrame(data, columns=columns)
            #feedback["df"] = pd.DataFrame(data)
            print("data retrieved and packed in response object")
    except Exception as e:
        feedback["debug"] += logger.error(f"Error executing query or connecting to data source: {str(e)}")
    return feedback
    print("data retrieving completed") 