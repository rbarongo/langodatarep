import os
import pandas as pd
from langodata.utils.database import DatabaseConnection
from langodata.utils.logger import Logger


def read_macro_data(data_group: str, data_source: str, data_type: str, data_frequency: str, start_period: str, end_period: str) -> dict:
    """
    Reads Time Series BOT data from the specified data source and returns a result dictionary.

    Args:
        data_group (str): The data group ("MACRO"). 
        data_source (str): The data source ("DOMESTIC").
        data_type (str): The type of data to fetch ("BOP", "CPI", "NATIONAL-ACCOUNTS", "FISCAL", "MONETARY", "INTEREST-RATES", "COMMODITIES-PRICES","REAL-SECTOR").
        data_frequency (str): Frequency ("DAILY","MONTHLY","QUARTERLY","ANNUAL-CALENDAR","ANNUAL-FINANCIAL").
        start_period (str): Start date of the period (YYYY-MM-DD).
        end_period (str): End date of the period (YYYY-MM-DD).

    Returns:
        dict: Contains Info, Debug, Contains SQL query, and column names.
    """
    logger = Logger()

    result    = {"info": "", "debug": "", "df": pd.DataFrame()}
    
    
    # Validate inputs
    valid_data_group = ["MACRO"]
    valid_data_sources = ["DOMESTIC"]
    valid_data_types =  ["BOP", "CPI", "NATIONAL-ACCOUNTS", "FISCAL", "MONETARY", "INTEREST-RATES", "COMMODITIES-PRICES","REAL-SECTOR"]
    valid_data_format = ["WIDE", "LONG"]
    valid_data_frequencies = ["DAILY","MONTHLY","QUARTERLY","ANNUAL-CALENDAR","ANNUAL-FINANCIAL"]

    if data_source not in valid_data_sources:
        result["debug"] += f"Invalid data source: {data_source}. "
        return result
    if data_type not in valid_data_types:
        result["debug"] += f"Invalid data type: {data_type}. "
        return result
    if data_group not in valid_data_group:
        result["debug"] += f"Invalid data group: {data_group}. "
        return result
    if data_frequency not in valid_data_frequencies:    
        result["debug"] += f"Invalid data frequency: {data_frequency}. "
        return result

        
    try:
    
        # Determine schema
        with DatabaseConnection(data_source) as conn:
    
            if data_source == "MACRO":
                schema = "" if "CONS" in data_type else "DWH."
            else:
                schema = ""            
            
            table_mapping = {
                "FACT_CPI":"CPI"
                }
            data_table =    table_mapping.get(data_type)
            #Define SQL query
            table_name = f"{schema}{data_table}"            
            condition = "1=1" #if bank_code == "*" else f"INSTITUTIONCODE = '{bank_code}'" 
            
            # Determine the frequency code for the WHERE clause
            freq_code = {
                "DAILY": "D", "MONTHLY": "M", "QUARTERLY": "Q", 
                "ANNUAL-CALENDAR": "A", "ANNUAL-FINANCIAL": "F"
            }.get(data_frequency, "M")

            sql_mapping = {
                "CPI": f"""
                    SELECT 
                        T.TIME_PERIOD,
                        T.YEAR,
                        T.MONTH,
                        L.LOCATION_NAME,
                        L.LOCATION_ISO,
                        I.INDICATOR_NAME,
                        I.DESCRIPTION AS INDICATOR_DESCRIPTION,
                        F.VALUE,
                        U.UNIT,
                        FR.FREQUENCY,
                        S.SOURCE
                FROM {table_name} F
                JOIN DWH.DIM_TIME T       ON F.TIME_ID = T.TIME_ID
                JOIN DWH.DIM_LOCATION L   ON F.LOCATION_ID = L.LOCATION_ID
                JOIN DWH.DIM_INDICATOR I  ON F.INDICATOR_ID = I.INDICATOR_ID
                JOIN DWH.DIM_UNITS U      ON F.UNIT_ID = U.UNIT_ID
                JOIN DWH.DIM_FREQ FR      ON F.FREQ_ID = FR.FREQ_ID
                JOIN DWH.DIM_SOURCES S    ON F.SOURCE_ID = S.SOURCE_ID
                WHERE {condition} 
                AND T.TIME_PERIOD BETWEEN TO_DATE('{start_period}', 'YYYY-MM-DD') 
                    AND TO_DATE('{end_period}', 'YYYY-MM-DD')
                    AND FR.FREQUENCY = '{data_frequency[0]}' -- Takes 'M' from 'MONTHLY', 'Q' from 'QUARTERLY'
                """
                }
          
            sql = sql_mapping.get(data_type, f"""
                SELECT * FROM {table_name}
                WHERE {condition} AND TRUNC(REPORTINGDATE) BETWEEN '{start_period}' AND '{end_period}'
                """)
           
            
            
            #result['sql_query']= sql
            
            
            #print(f"sql is : {sql}")


        
            #Fetch data
            data = conn.execute_query(sql)
     

            #Define columns based on data_type
            columns_mapping = {
                "CPI": ["TIME_PERIOD", "YEAR", "MONTH", "LOCATION_NAME", "LOCATION_ISO", 
                       "INDICATOR_NAME", "INDICATOR_DESCRIPTION", "VALUE", "UNIT", 
                       "FREQUENCY", "SOURCE"]                      

            }
            columns = columns_mapping.get(data_type)
            if not columns:
                raise ValueError(f"Invalid data_type '{data_type}'. No column mapping found.")
                
   
                
            #Construct DataFrame
            #result["columns_names"] = columns
            if data:            
                result["df"] = pd.DataFrame(data, columns=columns)
            else:
                logger.warning("No data found for the given parameters")
            logger.info(f"Data successfully retrieved.")
            #print(result["df"].head())
    except Exception as e:
        error_message = f"Error fetching MSP data: {str(e)}"
        result["debug"] += str(error_message) if error_message else ""
        logger.error(error_message)

    #result['info'] = logger.info("Fetching data completed successfully.")
    #result['debug'] += logger.debug(f"Executed SQL query: {sql}")
    return result



