def load_sample_data():
    """
    Dummy data loader for testing structure
    """
    return [
        {"id": 1, "value": "alpha"},
        {"id": 2, "value": "beta"},
        {"id": 3, "value": "gamma"},
    ]