username = "BSIS_DEV"
password = "bsis_dev"
dsn = "172.16.1.167:1521/BOT1DB"
APP_NAME = "LangoData"  # Application name for Oracle DB connections
ENV = "development"  # Environment setting: development, testing, production


